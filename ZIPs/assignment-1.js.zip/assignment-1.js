var numbers = [];
for (var i = 0; i<10; i++) {
	numbers.push(i);
}
console.log(numbers[0]);
console.log(numbers.pop());

var car = {};
car.colour = 'black';
console.log(car);
